# Teamwork Questionnaire for Michael Chaney

1. __Is it generally easier to reach you by text, electronic mail, voice mail or something else?  What hours?__
   +@me on Slack will get my attention, it'll notify my phone so I'll be able to get to it as soon as possible. After 4 on weekdays is when i'll most likely be free to do work
1. __What are your expectations about what your team will accomplish this semester?__
   +I expect us to all get a better understanding of what it means to work in a team, and hopefully make a cool project as well
1. __What are your personal goals for improving your teamwork and communication skills this semester?__
 	+My personal goal is to learn how to both lead and follow, and learn to recognize when one is necesarry over the other.
1. __What kinds of obstacles might you encounter in trying to reach both your team and personal goals?__
   +An obstacle I might encounter could be if my other teammates aren't willing to work for the goal
1. __What happens if some people on the team want to get an “A” while others think a “B” will be acceptable?__
   +It would be unfair for someone who wanted a B to bring down others who wanted an A.
1. __Is it acceptable for some team members to do more work on the assignment in order to get an “A”?__
   +This would happen if there is some kind of failure in how we divide tasks, but given that it can be difficult to gauge how difficult something will be, I think this might be inevitable, but it should be our goal to minimize this.
1. __How much time per week do you anticipate it will take to make the project successful?__
   +9 hours seems reasonable.
1. __How will you decide who should do what on the project and activities?__
   +We should try to divide it up by how difficult it would be per person. So people who want to learn a new tech could do that, and the difficulty of learning it would be considered when we divide tasks. But in a crunch it should be who can get it done most efficiently.
1. __What will happen if someone doesn’t follow through on a commitment (missing deadline, no show, etc.)?__
   +Their grade should be worse, and they should be expected to do additional work proportional to how difficult they made it for the rest of the team.
1. __What happens if people have different opinions on the quality of the work?__
   +We should work together to help people with lower quality work learn how to produce higher quality work.
1. __How will you deal with different work habits of team members?__
   +If they negativly effect the team, we should talk about a compromise that can be made that helps the team.
1. __Do you want to have a standing meeting time outside of class?__
   +We should have a time or times that we always plan on going to, but we can cancel if it's unnessesary
1. __How often do you think the team will need to meet outside of class?__
   +I think once a week would be a good baseline, with additional time decided after we start getting in the swing of things
1. __Will you need approval of every team member before making a decision?__
   +No, if it's a big/risky decision get approval, but for small choices indiviuals can handle themselves.
1. __What will you do if every team member except one agrees on something?__
   +Take a little extra time to compare why both sides think that way, and then go majority
1. __What will you do if one person seems to be dominating the team process?__
   +Try and communicate with the entire group, and try to find a better dynamic. One person dominating could happen because of one person being overly pushy, but also from some people being to timid.
1. __What will you do if you feel most of the facilitation responsibilities are falling on you?__
   +Communicate with the team, and see if a better dynamic is possible
