# Inspection - Team T09 
 
| Inspection | Details |
| ----- | ----- |
| Subject | NearestNeighbor.java |
| Meeting | 4/8, 3:00pm, CS314 class |
| Checklist | http://www.cs.toronto.edu/~sme/CSC444F/handouts/java_checklist.pdf |

### Roles

| Name | Preparation Time |
| ---- | ---- |
| Sharon Zhu | 1:00 |
| Will Domier | 1:00 |
| Michael Chaney | 1:00 |
| William Scarbro | 1:00 |

### Problems found

| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| NearestNeighbor.java:42 | wrong time start | low | Sharon | |
| NearestNeighbor.java:54 | calculating total distance doesn't include looping back to start | high| Michael | 251 |
| NearestNeighbor.java:56,83 | Should return after catching error | low | William | 252 | 
| NearestNeighbor.java: 65,83 | Should be using a different method of handling errors| low | wdomier | #253 |
|  | | | | |
