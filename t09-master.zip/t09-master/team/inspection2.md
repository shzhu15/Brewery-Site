# Inspection - Team *T09* 
 
| Inspection | Details |
| ----- | ----- |
| Subject | Itinerary.js |
| Meeting | 	4/8, 3:00pm, CS314 class |
| Checklist | http://www.cs.toronto.edu/~sme/CSC444F/handouts/java_checklist.pdf |

### Roles

| Name | Preparation Time |
| ---- | ---- |
| Sharon Zhu | 1:00 |
| Will Domier | 1:00 |
| Michael Chaney | 1:00 |
| William Scarbro | 1:00 |

### Problems found

| file:line | problem | hi/med/low | who found | github#  |
| --- | --- | :---: | :---: | --- |
| Itinerary.js:378 | Normal icon and intermediate icon are the same | low | wdomier | #261 |
|  Itinerary.js:141 | Last marker icon is not created. | Low | wscarbro | #262| 
| Itinerary.js:42 | Short swaps first local | High | chaney | #264 |
| Itinerary.js:286-309| duplicate code | Low | shzhu15 | |
 
