# T09 \#Include
<div>
  <image src="https://github.com/csucs314s19/t09/blob/master/team/images/cat.jpg" width="300">
    <div>This cat has heterochromia!</div>
</div>

| name          | eID    | GitHub Username | Email                           |
|---------------|--------|-----------------|---------------------------------|
|Sharon Zhu     |shzhu   |shzhu15          |shzhu@rams.colostate.edu         |
|Will Domier    |wdomier |wdomier          |wdomier@rams.colostate.edu       |
|Michael Chaney |chaney  |mchaney22        |mchaney22@outlook.com            |
|William Scarbro|wscarbro|WilliamScarbro   |wscarbro@rams.colostate.edu      |

